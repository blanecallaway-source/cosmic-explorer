Cosmic Explorer v7
Upload index.html AND the entire textures folder to the ROOT of your GitHub Pages repository.
The 3D engine loads from jsDelivr CDN, so an internet connection is required.
The planet texture files are included locally and are procedural approximations, NOT NASA photographs.
If GitHub Pages seems unchanged, wait for deployment and reload without cache.
